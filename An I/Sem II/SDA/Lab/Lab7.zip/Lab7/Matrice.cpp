#include "Matrice.h"

#include <exception>

using namespace std;

//Complexitate: Tetha(n*m)
Matrice::Matrice(int m, int n) {
    nrLiniiMatrice = m;
    nrColoaneMatrice = n;
    // creez matricea
    matrice = new Nod*[nrLiniiMatrice];
    radacina = new Nod();
    for(int i = 0; i < nrLiniiMatrice; i++)
    {
        matrice[i] = new Nod[nrColoaneMatrice];
        for(int j = 0; j < nrColoaneMatrice; j++)
        {
            matrice[i][j].stanga = nullptr;
            matrice[i][j].dreapta = nullptr;
            matrice[i][j].linie = -1;
            matrice[i][j].coloana = -1;
            matrice[i][j].valoare = NULL_TELEMENT;
        }
    }
}


//Complexitate Teta(1)
int Matrice::nrLinii() const{
	/* de adaugat */
	return nrLiniiMatrice;
}

//Complexitate Teta(1)
int Matrice::nrColoane() const{
	/* de adaugat */
	return nrColoaneMatrice;
}

//Complexitate:
//BestCase Teta(1) cand nu se da o pozitie valida in matrice sau cand nodul cautat se afla in radacina
//WorstCase Teta(h) cand nodul cautat se afla pe o frunza a arborelui aflata la adancimea maxima a arborelui
//Final - O(h)
TElem Matrice::element(int i, int j) const{
    /* de adaugat */
    if(i < 0 || i >= nrLiniiMatrice || j < 0 || j >= nrColoaneMatrice)
        throw exception();
    return cautaNod(radacina, i, j);
}


//Complexitate:
//BestCase - cand nu se da o pozitie valida in matrice Teta(1) sau cand se modifica un element care se afla in radacina
//WorstCase - Teta(h) cand se modifica un element care se afla pe o frunza a arborelui aflata la adancimea maxima a arborelui
//Final - O(h)
TElem Matrice::modifica(int i, int j, TElem e) {
    if(i < 0 || i >= nrLiniiMatrice || j < 0 || j >= nrColoaneMatrice)
        throw exception();
    TElem valoare = cautaNod(radacina, i, j);
    if(valoare == NULL_TELEMENT)
    {
        Nod* nod = creeazaNod(i, j, e);
        Nod* nodCurent = radacina;
        while(true)
        {
            if(nodCurent->linie > i || (nodCurent->linie == i && nodCurent->coloana > j))
            {
                if(nodCurent->stanga == nullptr)
                {
                    nodCurent->stanga = nod;
                    break;
                }
                nodCurent = nodCurent->stanga;
            }
            else
            {
                if(nodCurent->dreapta == nullptr)
                {
                    nodCurent->dreapta = nod;
                    break;
                }
                nodCurent = nodCurent->dreapta;
            }
        }
    }
    else
    {
        Nod* nodCurent = radacina;
        while(true)
        {
            if(nodCurent->linie == i && nodCurent->coloana == j)
            {
                nodCurent->valoare = e;
                break;
            }
            if(nodCurent->linie > i || (nodCurent->linie == i && nodCurent->coloana > j))
                nodCurent = nodCurent->stanga;
            else
                nodCurent = nodCurent->dreapta;
        }
    }
    return valoare;
}


//Complexitate: Teta(1)
Matrice::Nod *Matrice::creeazaNod(int linie, int coloana, TElem valoare) {
    Nod* nod = new Nod();
    nod->linie = linie;
    nod->coloana = coloana;
    nod->valoare = valoare;
    nod->stanga = nullptr;
    nod->dreapta = nullptr;
    return nod;
}

//Complexitate:
//BestCase - Cand elementul se afla in radacina sau arborele nu are elemente Teta(1)
//WorstCase - cand elementul se afla pe o frunza a arborelui aflata la adancimea maxima a arborelui Teta(h)
//Final - O(h)
TElem Matrice::cautaNod(Matrice::Nod *nod, int linie, int coloana) const {
    if(nod == nullptr)
        return NULL_TELEMENT;
    if(nod->linie == linie && nod->coloana == coloana)
        return nod->valoare;
    if(nod->linie > linie || (nod->linie == linie && nod->coloana > coloana))
        return cautaNod(nod->stanga, linie, coloana);
    return cautaNod(nod->dreapta, linie, coloana);
}


