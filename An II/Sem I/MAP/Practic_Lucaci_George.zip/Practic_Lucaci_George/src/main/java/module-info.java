module com.example.practic_lucaci_george {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires java.sql;

    opens com.example.practic_lucaci_george to javafx.fxml;
    exports com.example.practic_lucaci_george;
    exports com.example.practic_lucaci_george.Controller;
    opens com.example.practic_lucaci_george.Controller to javafx.fxml;
}