package com.example.practic_lucaci_george.Domain;

import com.example.practic_lucaci_george.Utils.Type;

public class Animal extends Entity<Long>{
    private String name;
    private Long centreId;
    private Type type;

    public Animal(String name, Long centreId, Type type) {
        this.name = name;
        this.centreId = centreId;
        this.type = type;
    }
    @Override
    public String toString() {
        return "Animal{" +
                "name='" + name + '\'' +
                ", centreId=" + centreId +
                ", type=" + type +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getCentreId() {
        return centreId;
    }

    public void setCentreId(Long centreId) {
        this.centreId = centreId;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }
}
