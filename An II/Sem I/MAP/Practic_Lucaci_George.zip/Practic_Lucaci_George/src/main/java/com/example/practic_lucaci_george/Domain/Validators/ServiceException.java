package com.example.practic_lucaci_george.Domain.Validators;

public class ServiceException extends RuntimeException {
    public ServiceException(String message) {
        super(message);
    }
}
