package com.example.practic_lucaci_george.Observer;


import com.example.practic_lucaci_george.Domain.AdoptionCentre;
import com.example.practic_lucaci_george.Domain.Animal;

public class AnimalTransferEvent {
    private final Long requestingCentreId;  // Centrul care solicită transferul
    private final String message;           // Mesajul de notificare
    private final Animal animal;

    public AnimalTransferEvent(Long requestingCentreId, String message, Animal animal) {
        this.requestingCentreId = requestingCentreId;
        this.message = message;
        this.animal = animal;
    }

    public Animal getAnimal() {
        return animal;
    }


    public Long getRequestingCentreId() {
        return requestingCentreId;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public String toString() {
        return "AnimalTransferEvent{" +
                "requestingCentreId=" + requestingCentreId +
                ", message='" + message + '\'' +
                '}';
    }


}

