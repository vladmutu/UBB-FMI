package com.example.practic_lucaci_george.Repository;

import com.example.practic_lucaci_george.Domain.AdoptionCentre;
import com.example.practic_lucaci_george.Domain.Animal;
import com.example.practic_lucaci_george.Domain.Validators.Validator;

import java.sql.*;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

public class AdoptionC_DB_R implements AdoptionCRepository {

    private final String url;
    private final String username;
    private final String password;
    private Validator<AdoptionCentre> validator;


    public AdoptionC_DB_R(String url, String username, String password, Validator<AdoptionCentre> validator) {
        this.url = url;
        this.username = username;
        this.password = password;
        this.validator = validator;
    }

    @Override
    public Optional<AdoptionCentre> findOne(Long aLong) {
        String query = "SELECT * FROM adoptioncentre WHERE id_centre = ?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, aLong);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                String name = resultSet.getString("name");
                String location = resultSet.getString("location");
                Long capacity = resultSet.getLong("capacity");

                AdoptionCentre adoptionCentre = new AdoptionCentre(name,location,capacity);
                adoptionCentre.setId(aLong);

                return Optional.of(adoptionCentre);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public Iterable<AdoptionCentre> findAll() {
        Set<AdoptionCentre> centres = new HashSet<>();
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM adoptioncentre");
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Long id = resultSet.getLong("id_centre");
                String name = resultSet.getString("name");
                String location = resultSet.getString("location");
                Long capacity = resultSet.getLong("capacity");

                AdoptionCentre c = new AdoptionCentre(name,location,capacity);
                c.setId(id);
                centres.add(c);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return centres;
    }

    @Override
    public Optional<AdoptionCentre> save(AdoptionCentre entity) {
        return Optional.empty();
    }

    @Override
    public Optional<AdoptionCentre> delete(Long aLong) {
        return Optional.empty();
    }

    @Override
    public Optional<AdoptionCentre> update(AdoptionCentre entity) {
        return Optional.empty();
    }

    @Override
    public Iterable<AdoptionCentre> findCentreByLocation(String location) {
        Set<AdoptionCentre> centres = new HashSet<>();
        String query = "SELECT * FROM adoptioncentre WHERE location = ?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, location);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()) {
                Long id = resultSet.getLong("id_centre");
                String name = resultSet.getString("name");
                Long capacity = resultSet.getLong("capacity");
                AdoptionCentre c = new AdoptionCentre(name,location,capacity);
                c.setId(id);
                centres.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return centres;
    }
}
