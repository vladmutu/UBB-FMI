package com.example.practic_lucaci_george.Observer;

public interface Observer<E> {
    void update(E e);
}
