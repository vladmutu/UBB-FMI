package com.example.practic_lucaci_george.Domain.Validators;

import com.example.practic_lucaci_george.Domain.AdoptionCentre;

public class CentreValidator implements Validator<AdoptionCentre> {
    @Override
    public void validate(AdoptionCentre entity) throws ServiceException {
        //TODO: implement method validate
        if(entity.getName().equals("") || entity.getLocation().equals("") || entity.getId() == null)
            throw new ValidationException("Centrul nu este valid");
    }
}
