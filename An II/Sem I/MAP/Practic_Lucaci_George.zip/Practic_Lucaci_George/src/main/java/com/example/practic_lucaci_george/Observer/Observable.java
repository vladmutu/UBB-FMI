package com.example.practic_lucaci_george.Observer;

public interface Observable <E>{
    void addObserver(Observer<E> e);
    void removeObserver(Observer<E> e);
    void notifyObserver(E t);
}
