package com.example.practic_lucaci_george.Repository;

import com.example.practic_lucaci_george.Domain.AdoptionCentre;
import com.example.practic_lucaci_george.Domain.Animal;
import com.example.practic_lucaci_george.Utils.Type;

public interface AdoptionCRepository extends Repository<Long, AdoptionCentre> {
    Iterable<AdoptionCentre> findCentreByLocation(String location);

}
