package com.example.practic_lucaci_george;

import com.example.practic_lucaci_george.Controller.HelloController;
import com.example.practic_lucaci_george.Domain.AdoptionCentre;
import com.example.practic_lucaci_george.Domain.Animal;
import com.example.practic_lucaci_george.Domain.Validators.AnimalValidator;
import com.example.practic_lucaci_george.Domain.Validators.CentreValidator;
import com.example.practic_lucaci_george.Repository.*;
import com.example.practic_lucaci_george.Service.Service;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        String username="postgres";
        String password="12345678";
        String url="jdbc:postgresql://localhost:5432/practic";

    //    Repository<Long, AdoptionCentre> centreRepository = new AdoptionC_DB_R(url, username,password, new CentreValidator());
     //   Repository<Long, Animal> animalRepository = new Animal_DB_R(url, username, password, new AnimalValidator());
        AnimalRepository animalRepository = new Animal_DB_R(url, username, password, new AnimalValidator());
        AdoptionCRepository centreRepository = new AdoptionC_DB_R(url, username, password, new CentreValidator());
        Service service = new Service(centreRepository, animalRepository);


        for(AdoptionCentre a : centreRepository.findAll()){
            System.out.println(a);
        }


        for(AdoptionCentre centre : centreRepository.findAll()){
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 320, 440);


            HelloController controller = fxmlLoader.getController();
            controller.setServiceAndCentre(service,centre);
           // controller.setCentre(centre);
            Stage newStage = new Stage();
            newStage.setTitle(centre.getName());
            newStage.setScene(scene);
            newStage.show();
        }

       // FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        //Scene scene = new Scene(fxmlLoader.load(), 320, 240);
       // stage.setTitle("Hello!");
        //stage.setScene(scene);
        //stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}