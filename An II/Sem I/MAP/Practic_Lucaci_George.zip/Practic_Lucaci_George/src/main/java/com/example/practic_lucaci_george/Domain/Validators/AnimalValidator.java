package com.example.practic_lucaci_george.Domain.Validators;

import com.example.practic_lucaci_george.Domain.Animal;

public class AnimalValidator implements Validator<Animal> {
    @Override
    public void validate(Animal entity) throws ServiceException {
        //TODO: implement method validate
        if(entity.getName().equals("") || entity.getId() == null)
            throw new ValidationException("Centrul nu este valid");
    }
}
