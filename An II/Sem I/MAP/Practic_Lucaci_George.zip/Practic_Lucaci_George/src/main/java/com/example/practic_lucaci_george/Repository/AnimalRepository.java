package com.example.practic_lucaci_george.Repository;

import com.example.practic_lucaci_george.Domain.Animal;
import com.example.practic_lucaci_george.Utils.Type;

public interface AnimalRepository extends Repository<Long, Animal> {
    Iterable<Animal> findAnimalByType(Type type);
}