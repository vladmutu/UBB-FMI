package com.example.practic_lucaci_george.Service;

import com.example.practic_lucaci_george.Controller.HelloController;
import com.example.practic_lucaci_george.Domain.AdoptionCentre;
import com.example.practic_lucaci_george.Domain.Animal;
import com.example.practic_lucaci_george.Observer.AnimalTransferEvent;
import com.example.practic_lucaci_george.Observer.Observable;
import com.example.practic_lucaci_george.Observer.Observer;
import com.example.practic_lucaci_george.Repository.AdoptionCRepository;
import com.example.practic_lucaci_george.Repository.AnimalRepository;
import com.example.practic_lucaci_george.Repository.Repository;
import com.example.practic_lucaci_george.Utils.Type;

import java.util.*;

public class Service implements Observable<AnimalTransferEvent> {

    private AdoptionCRepository centreRepository;
    private AnimalRepository animalRepository;
    private List<Observer<AnimalTransferEvent>> observers = new ArrayList<>();


    public Service(AdoptionCRepository centreRepository, AnimalRepository animalRepository) {
        this.centreRepository = centreRepository;
        this.animalRepository = animalRepository;
    }


    AdoptionCentre findCentre(Long id){
        Optional<AdoptionCentre> centreOptional = centreRepository.findOne(id);
        if (centreOptional.isPresent()) {
            return centreOptional.get();  // Returnează centrul
        } else {
            return null;
        }    }

    public void request_transfer(Long requestingCentreId, Animal animal) {
        String message = "Centrul " + findCentre(requestingCentreId).getName() + " requested to transfer " + animal.getName();

        AnimalTransferEvent event = new AnimalTransferEvent(requestingCentreId, message, animal);

        notifyObserver(event);
    }


    @Override
    public void addObserver(Observer<AnimalTransferEvent> observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer<AnimalTransferEvent> observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObserver(AnimalTransferEvent event) {
        for (Observer<AnimalTransferEvent> observer : observers) {

            if (observer instanceof HelloController) {
                HelloController controller = (HelloController) observer;
                AdoptionCentre requestingCentre = findCentre(event.getRequestingCentreId());
                if (controller.getCentre().getLocation().equals(requestingCentre.getLocation()) && !requestingCentre.getId().equals(controller.getCentre().getId())) {
                    observer.update(event);
                }
            }
        }
    }


    public Iterable<Animal> get_animals_from_centre(Long centre_id){
        Set<Animal> animals = new HashSet<>();
        for(Animal animal : animalRepository.findAll()){
            if(animal.getCentreId() == centre_id){
                animals.add(animal);
            }
        }
        return animals;
    }

    public Iterable<Animal> get_animals_by_type(Type type){
        return animalRepository.findAnimalByType(type);
    }

    public Iterable<Animal> get_animals_by_type_from_centre(Type type, Long centre_id){
        Set<Animal> animals = new HashSet<>();
        for(Animal animal : get_animals_by_type(type)){
            if(animal.getCentreId() == centre_id){
                animals.add(animal);
            }
        }
        return animals;
    }

    public Long get_occupancy_grade_from_centre(Long centre_id, Long centre_size){
        Long animal_count = 0L;
        for(Animal animal : animalRepository.findAll()){
            if(animal.getCentreId() == centre_id){
                animal_count++;
            }
        }
        if (centre_size == 0) return 0L;
        return (animal_count * 100) / centre_size;
    }
}
