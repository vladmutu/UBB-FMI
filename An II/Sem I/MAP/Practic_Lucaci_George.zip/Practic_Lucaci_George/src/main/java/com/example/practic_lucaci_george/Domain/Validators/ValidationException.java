package com.example.practic_lucaci_george.Domain.Validators;

public class ValidationException extends RuntimeException {
    public ValidationException(String message) {
        super(message);
    }
}

