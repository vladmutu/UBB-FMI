package com.example.practic_lucaci_george.Controller;

import com.example.practic_lucaci_george.Domain.AdoptionCentre;
import com.example.practic_lucaci_george.Domain.Animal;
import com.example.practic_lucaci_george.Observer.AnimalTransferEvent;
import com.example.practic_lucaci_george.Observer.Observer;
import com.example.practic_lucaci_george.Service.Service;
import com.example.practic_lucaci_george.Utils.Type;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class HelloController implements Observer<AnimalTransferEvent> {



    private static List<Alert> activeAlerts = new ArrayList<>();

    @FXML
    private ComboBox cmbType;
    @FXML
    private TableView<Animal> tableAnimals;
    @FXML
    private TableColumn<Animal, String> columnAnimalName;
    @FXML
    private TableColumn<Animal,String> columnAnimalType;
    @FXML
    private Label lblCentreInfo;
    @FXML
    private Label lblOccupancyGrade;

    private ObservableList<Animal> observableAnimals = FXCollections.observableArrayList();


    private Service service;

    private AdoptionCentre centre;

    public void registerObserver(Service service) {
        service.addObserver(this);
    }

    @Override
    public void update(AnimalTransferEvent event) {
        System.out.println("Notificare: " + event.getMessage());
/*
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Cerere Transfer");
            alert.setHeaderText(centre.getName());
            alert.setContentText(event.getMessage());
            alert.showAndWait();
        });*/

        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Cerere Transfer");
            alert.setHeaderText(centre.getName());
            alert.setContentText(event.getMessage());

            ButtonType buttonTypeAccept = new ButtonType("Accept");
            ButtonType buttonTypeIgnore = new ButtonType("Ignore");

            alert.getButtonTypes().setAll(buttonTypeAccept, buttonTypeIgnore);

            activeAlerts.add(alert);


            alert.showAndWait().ifPresent(response -> {
                if (response == buttonTypeAccept) {
                    System.out.println(activeAlerts.size());
                    System.out.println("Cerere transfer acceptata.");
                    closeAllActiveAlerts();
                } else if (response == buttonTypeIgnore) {
                    System.out.println("Cerere transfer ignorata.");
                }
            });
        });
    }

    private void closeAllActiveAlerts() {
        Platform.runLater(() -> {
            for (Alert alert : activeAlerts) {
                if (alert.isShowing()) {
                    alert.close();
                }
            }
            activeAlerts.clear();
        });
    }



    public void setServiceAndCentre(Service service, AdoptionCentre centre) {
        this.service = service;
        this.centre = centre;
        init_labels();
        init_table();
        init_cmb();
        load_data();
        registerObserver(service);
    }

    private void init_labels(){
        lblCentreInfo.setText("Name: " + centre.getName() +"  Locatie: " + centre.getLocation() + "  Capacitate: " + centre.getCapacity());
        lblOccupancyGrade.setText("Occupancy: " + service.get_occupancy_grade_from_centre(centre.getId(),centre.getCapacity()) + "%");

    }



    private void load_data(){
        for(Animal animal : service.get_animals_from_centre(centre.getId())){
            observableAnimals.add(animal);
        }

        for(Type type : Type.values()){
            cmbType.getItems().add(type);
        }

    }

    private void init_cmb(){
        cmbType.setOnAction(event -> {
            Type selectedType =(Type) cmbType.getSelectionModel().getSelectedItem();
            if (selectedType != null) {
                handleTypeSelection(selectedType);
            }
        });
    }

    private void handleTypeSelection(Type selectedType) {

        observableAnimals.clear();
        if(selectedType.equals(Type.valueOf("AllTypes"))) {
            // Dacă este selectat "All types", afișăm toate animalele din centru
            for (Animal animal : service.get_animals_from_centre(centre.getId())) {
                observableAnimals.add(animal);
            }
            return;
        }/*
        if(selectedType.toString().equals("All types")){
            for(Animal animal : service.get_animals_from_centre(centre.getId())){
                observableAnimals.add(animal);
            }
        }*/
        for(Animal animal : service.get_animals_by_type_from_centre(selectedType, centre.getId())){
            observableAnimals.add(animal);
        }
    }

    private void init_table(){
        tableAnimals.getItems().clear();
        tableAnimals.setItems(observableAnimals);
        columnAnimalName.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getName())
        );
        columnAnimalType.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getType().toString())
        );
    }

    public void handleReqTransfer(ActionEvent actionEvent) {
        Animal selectedAnimal = tableAnimals.getSelectionModel().getSelectedItem();

        if (selectedAnimal == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Eroare");
            alert.setHeaderText(null);
            alert.setContentText("Te rugam să selectezi un animal din tabel.");
            alert.showAndWait();
            return;
        }

        service.request_transfer(centre.getId(), selectedAnimal);
    }

    public AdoptionCentre getCentre() {
        return centre;
    }

    /*
    public void setCentre(AdoptionCentre centre) {
        this.centre = centre;
        lblCentreInfo.setText("Name: " + centre.getName() +"  Locatie: " + centre.getLocation() + "  Capacitate: " + centre.getCapacity());
        lblOccupancyGrade.setText("Occupancy: " + service.get_occupancy_grade_from_centre(centre.getId(),centre.getCapacity()) + "%");

    }*/


    //<VBox alignment="CENTER" spacing="20.0" xmlns:fx="http://javafx.com/fxml/1" xmlns="http://javafx.com/javafx/17.0.12" fx:controller="com.example.practic_lucaci_george.Controller.HelloController">

}