package com.example.practic_lucaci_george.Repository;

import com.example.practic_lucaci_george.Domain.AdoptionCentre;
import com.example.practic_lucaci_george.Domain.Animal;
import com.example.practic_lucaci_george.Domain.Validators.Validator;
import com.example.practic_lucaci_george.Utils.Type;

import java.sql.*;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

public class Animal_DB_R implements AnimalRepository {

    private final String url;
    private final String username;
    private final String password;
    private Validator<Animal> validator;


    public Animal_DB_R(String url, String username, String password, Validator<Animal> validator) {
        this.url = url;
        this.username = username;
        this.password = password;
        this.validator = validator;
    }

    @Override
    public Optional<Animal> findOne(Long aLong) {
        return Optional.empty();
    }


    @Override
    public Iterable<Animal> findAnimalByType(Type type){
        Set<Animal> animals = new HashSet<>();
        String query = "SELECT * FROM animal WHERE type = ?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, type.toString());
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()) {
                Long id = resultSet.getLong("id_animal");
                String name = resultSet.getString("name");
                Long id_centre = resultSet.getLong("id_centre");
                Animal a = new Animal(name,id_centre,type);
                a.setId(id);
                animals.add(a);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return animals;
    }


    @Override
    public Iterable<Animal> findAll() {
        Set<Animal> animals = new HashSet<>();
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM animal");
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Long id = resultSet.getLong("id_animal");
                String name = resultSet.getString("name");
                Long id_centre = resultSet.getLong("id_centre");
                Type type = Type.valueOf(resultSet.getString("type"));
                Animal a = new Animal(name,id_centre,type);
                a.setId(id);
                animals.add(a);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return animals;
    }

    @Override
    public Optional<Animal> save(Animal entity) {
        return Optional.empty();
    }

    @Override
    public Optional<Animal> delete(Long aLong) {
        return Optional.empty();
    }

    @Override
    public Optional<Animal> update(Animal entity) {
        return Optional.empty();
    }
}
