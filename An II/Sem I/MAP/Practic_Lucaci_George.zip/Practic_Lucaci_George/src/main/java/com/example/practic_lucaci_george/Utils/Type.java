package com.example.practic_lucaci_george.Utils;

public enum Type {
    AllTypes,
    Caine,
    Pisica,
    Pasare,
    Rozator,


}


