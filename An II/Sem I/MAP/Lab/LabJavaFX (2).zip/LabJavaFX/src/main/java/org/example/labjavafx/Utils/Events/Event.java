package org.example.labjavafx.Utils.Events;

public interface Event {
}
