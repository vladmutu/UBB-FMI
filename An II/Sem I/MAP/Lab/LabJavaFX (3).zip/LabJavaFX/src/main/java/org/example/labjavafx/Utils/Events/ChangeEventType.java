package org.example.labjavafx.Utils.Events;

public enum ChangeEventType {
    ADD,UPDATE,DELETE;
}
