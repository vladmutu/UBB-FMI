package org.example.practic_mutu_vlad.Utils;

public enum Status {
    PENDING, IN_PROGRESS, FINISHED
}
