package org.example.practic_mutu_vlad.Domain.Validators;

public class ServiceException extends RuntimeException {
    public ServiceException(String message) {
        super(message);
    }
}
