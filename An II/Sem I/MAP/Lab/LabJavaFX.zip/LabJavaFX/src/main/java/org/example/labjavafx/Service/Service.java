package org.example.labjavafx.Service;

import org.example.labjavafx.Domain.FriendRequest;
import org.example.labjavafx.Domain.Friendship;
import org.example.labjavafx.Domain.Message;
import org.example.labjavafx.Domain.User;
import org.example.labjavafx.Repository.Repository;
import org.example.labjavafx.Utils.Events.ChangeEventType;
import org.example.labjavafx.Utils.Events.UserEntityChangeEvent;
import org.example.labjavafx.Utils.Observer.Observable;
import org.example.labjavafx.Utils.Observer.Observer;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class Service implements Observable<UserEntityChangeEvent> {
    private Repository<Long, User> userRepository;
    private Repository<Long, Friendship> friendshipRepository;
    private List<Observer<UserEntityChangeEvent>> observers = new ArrayList<>();

    private final Repository<Long, Message> messageRepository;

    public Service(Repository<Long, User> userRepository, Repository<Long, Friendship> friendshipRepository, Repository<Long, Message> messageRepository) {
        this.userRepository = userRepository;
        this.friendshipRepository = friendshipRepository;
        this.messageRepository = messageRepository;
    }

    @Override
    public void addObserver(Observer<UserEntityChangeEvent> observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer<UserEntityChangeEvent> observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(UserEntityChangeEvent event) {
        observers.stream().forEach(observer -> observer.update(event));
    }

    public boolean checkIfEmailExists(String email) {
        return StreamSupport.stream(userRepository.findAll().spliterator(), false)
                .anyMatch(user -> user.getEmail().equals(email));
    }

    public User findOneByMailAndPassword(String email, String password) {
        return StreamSupport.stream(userRepository.findAll().spliterator(), false)
                .filter(user -> user.getEmail().equals(email) && user.getPassword().equals(password))
                .findFirst()
                .orElse(null);
    }

    public List<User> findOneByName(String name) {
        return StreamSupport.stream(userRepository.findAll().spliterator(), false)
                .filter(user -> user.getFirstName().equals(name) && user.getLastName().equals(name))
                .collect(Collectors.toList());
    }

    public List<User> findOneByFirstName(String name) {
        return StreamSupport.stream(userRepository.findAll().spliterator(), false)
                .filter(user -> user.getFirstName().equals(name))
                .collect(Collectors.toList());
    }

    public List<User> findOneByLastName(String name) {
        return StreamSupport.stream(userRepository.findAll().spliterator(), false)
                .filter(user -> user.getLastName().equals(name))
                .collect(Collectors.toList());
    }

    public LocalDateTime getFriendsSinceDate(Long user1, Long user2) {
        StringBuilder exceptions = new StringBuilder();
        if(user1.equals(user2)) {
            exceptions.append("You can't be friends with yourself!\n");
        }

        if(userRepository.findOne(user1).isEmpty()) {
            exceptions.append("User with id ").append(user1).append(" does not exist!\n");
        }

        if(userRepository.findOne(user2).isEmpty()) {
            exceptions.append("User with id ").append(user2).append(" does not exist!\n");
        }

        if(!exceptions.toString().isEmpty()) {
            throw new RuntimeException(exceptions.toString());
        }

        return StreamSupport.stream(friendshipRepository.findAll().spliterator(), false)
                .filter(friendship -> friendship.contains(user1) && friendship.contains(user2))
                .findFirst()
                .map(Friendship::getDate)
                .orElse(null);
    }

    public List<User> getFriends(Long id) {
        return StreamSupport.stream(userRepository.findAll().spliterator(), false)
                .filter(user -> user.getId().equals(id))
                .findFirst()
                .map(User::getFriends)
                .orElse(null);
    }

    public List<FriendRequest> getFriendRequests(Long id) {
        return StreamSupport.stream(friendshipRepository.findAll().spliterator(), false)
                .filter(friendship -> friendship.getId2().equals(id) && friendship.isPending())
                .map(friendship -> {
                    User user = userRepository.findOne(friendship.getId1()).orElse(null);
                    return new FriendRequest(user.getId(), user.getFirstName(), user.getLastName(), user.getEmail(), friendship.getDate());
                })
                .collect(Collectors.toList());
    }

    public List<User> getUsersFriends(Long id) {
        return StreamSupport.stream(friendshipRepository.findAll().spliterator(), false)
                .filter(friendship -> friendship.contains(id) && !friendship.isPending())
                .map(friendship -> userRepository.findOne(friendship.getId1()).orElse(null))
                .collect(Collectors.toList());
    }

    public User findOneUserByNameAndEmail(String firstName, String lastName, String email) {
        return StreamSupport.stream(userRepository.findAll().spliterator(), false)
                .filter(user -> user.getFirstName().equals(firstName) && user.getLastName().equals(lastName) && user.getEmail().equals(email))
                .findFirst()
                .orElse(null);
    }

    public List<Friendship> getPendingFriendships(Long id) {
        return StreamSupport.stream(friendshipRepository.findAll().spliterator(), false)
                .filter(friendship -> friendship.getId2().equals(id) && friendship.isPending())
                .collect(Collectors.toList());
    }

    public Iterable<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> findOneUser(Long id) {
        return userRepository.findOne(id);
    }

    public Long getNewUserId() {
        return StreamSupport.stream(userRepository.findAll().spliterator(), false)
                .map(User::getId)
                .max(Long::compareTo)
                .orElse(0L) + 1;
    }

    public User addUser(User u) {
        List<User> sameEmailUsers = StreamSupport.stream(userRepository.findAll().spliterator(), false)
                .filter(user -> user.getEmail().equals(u.getEmail()))
                .toList();
        if(!sameEmailUsers.isEmpty()) {
            throw new RuntimeException("Email already in use!");
        }
        else {
            u.setId(getNewUserId());
            if(userRepository.save(u).isEmpty()) {
                UserEntityChangeEvent event = new UserEntityChangeEvent(ChangeEventType.ADD, u);
                notifyObservers(event);
            }
            return u;
        }
    }

    public Iterable<Friendship> getFrienships() {
        return friendshipRepository.findAll();
    }

    public User removeUser(Long id) {
        List<Long> friendshipsToRemove = StreamSupport.stream(friendshipRepository.findAll().spliterator(), false)
                .filter(friendship -> friendship.contains(id))
                .map(Friendship::getId)
                .toList();
        friendshipsToRemove.forEach(friendshipRepository::delete);
        Optional<User> user = userRepository.delete(id);
        if(user.isEmpty()) {
            UserEntityChangeEvent event = new UserEntityChangeEvent(ChangeEventType.DELETE, user.get());
            notifyObservers(event);
        }
        return user.orElse(null);
    }

    public Long getNewFriendshipId() {
        return StreamSupport.stream(friendshipRepository.findAll().spliterator(), false)
                .map(Friendship::getId)
                .max(Long::compareTo)
                .orElse(0L) + 1;
    }


}

