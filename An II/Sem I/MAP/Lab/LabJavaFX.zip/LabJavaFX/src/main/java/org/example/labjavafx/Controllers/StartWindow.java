package org.example.labjavafx.Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.labjavafx.Domain.User;
import org.example.labjavafx.Service.Service;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class StartWindow {

    private Service service;

    public TextField emailField;

    public PasswordField passwordField;

    public TextField passwordFieldVisible;

    public CheckBox showPassword;

    public void setService(Service service) {
        this.service = service;
    }

    public void SignIn(ActionEvent actionEvent) {
        String email = emailField.getText();
        String password = passwordField.getText();
        if(email.isEmpty() || password.isEmpty()) {
            Dialog<String> dialog = new Dialog<>();
            dialog.setTitle("Error");
            dialog.setHeaderText("Error");
            dialog.setContentText("Please fill in all the fields");
        }
        if(!email.contains("@gmail.com") && !email.contains("@yahoo.com")) {
            Dialog<String> dialog = new Dialog<>();
            dialog.setTitle("Error");
            dialog.setHeaderText("Error");
            dialog.setContentText("Invalid email");
        }
        if(password.length() < 6) {
            Dialog<String> dialog = new Dialog<>();
            dialog.setTitle("Error");
            dialog.setHeaderText("Error");
            dialog.setContentText("Password must be at least 6 characters long");
        }
        Iterable<User> users = service.getAllUsers();
        users.forEach(user -> {
            if(user.getEmail().equals(email) && user.getPassword().equals(password)) {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/labjavafx/main-window.fxml"));
                    Parent root = loader.load();
                    Stage stage = new Stage();
                    MainWindow mainWindow = loader.getController();
                    mainWindow.setService(service);
                    stage.setTitle("Main Window");
                    stage.setScene(new Scene(root));
                    stage.show();
                    ((Stage) ((Button) actionEvent.getSource()).getScene().getWindow()).close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else {
                Dialog dialog = new Dialog();
                dialog.setContentText("Invalid email or password");
                ButtonType closeButton = new ButtonType("Close", ButtonBar.ButtonData.OK_DONE);
                dialog.getDialogPane().getButtonTypes().add(closeButton);
                dialog.showAndWait();
            }
        });
    }

    public void goToSignUp(ActionEvent actionEvent) throws IOException {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/labjavafx/sign-up-window.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            SignUpWindow signUpWindow = loader.getController();
            signUpWindow.setService(service);
            stage.setTitle("Sign Up");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void showHidePassword(ActionEvent actionEvent) {
        if(showPassword.isSelected()) {
            passwordFieldVisible.setText(passwordField.getText());
            passwordFieldVisible.setManaged(true);
            passwordFieldVisible.setVisible(true);
            passwordField.setManaged(false);
            passwordField.setVisible(false);
        }
        else {
            passwordField.setManaged(true);
            passwordField.setVisible(true);
            passwordField.setText(passwordField.getText());
        }
    }
}
