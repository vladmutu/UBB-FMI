package org.example.labjavafx.Controllers;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import org.example.labjavafx.Domain.FriendRequest;
import org.example.labjavafx.Domain.User;
import org.example.labjavafx.Service.Service;
import org.example.labjavafx.Utils.Events.UserEntityChangeEvent;
import org.example.labjavafx.Utils.Observer.Observable;
import org.example.labjavafx.Utils.Observer.Observer;

import java.util.List;

public class MainWindow implements Observer<UserEntityChangeEvent> {

    public TableView tableViewFriendRequests;

    public TableColumn tableColumnFirstName;

    public TableColumn tableColumnLastName;

    public TableColumn tableColumnEmail;

    public TableColumn tableColumnSendDate;

    public TableView tableViewFriends;
    public TableColumn tableColumnFirstNameFriend;
    public TableColumn tableColumnLastNameFriend;
    public TableColumn tableColumnEmailFriend;
    public TableColumn tableColumnFriendsFrom;

    private Service service;

    Observable<List<FriendRequest>> modelFriends = FXCollections.observableArrayList();
    Observable<List<FriendRequest>> modelFriendRequests = FXCollections.observableArrayList();

    User user;



    public void setService(Service service) {
        this.service = service;
    }

    @Override
    public void update(UserEntityChangeEvent userEntityChangeEvent) {

    }

    public void handleAcceptFriendRequest(ActionEvent actionEvent) {
    }

    public void handleDeclineFriendRequest(ActionEvent actionEvent) {
    }

    public void handleDeleteFriend(ActionEvent actionEvent) {
    }

    public void handleBackToLogin(ActionEvent actionEvent) {
    }

    public void handleUpdateUser(ActionEvent actionEvent) {
    }

    public void handleDeleteUser(ActionEvent actionEvent) {
    }

    public void handleAddFriend(ActionEvent actionEvent) {
    }

    public void handleChat(ActionEvent actionEvent) {
    }
}
