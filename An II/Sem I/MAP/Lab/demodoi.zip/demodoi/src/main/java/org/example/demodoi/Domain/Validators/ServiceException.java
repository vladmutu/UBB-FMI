package org.example.demodoi.Domain.Validators;

public class ServiceException extends RuntimeException {
    public ServiceException(String message) {
        super(message);
    }
}
