package org.example.demo1.Utils;

public interface Event {
}
