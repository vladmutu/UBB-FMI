package org.example.demo1.Utils;


import org.example.demo1.Domain.Entity;

public interface Observer<E extends Entity<Integer>> {
    void update(E e);
}
