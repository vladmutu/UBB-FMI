﻿namespace Lab11;

public abstract class AbstractSorter
{
    public abstract void sort(int[] elements);
}