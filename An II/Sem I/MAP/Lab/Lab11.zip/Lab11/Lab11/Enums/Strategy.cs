﻿namespace Lab11.Enums;

public enum Strategy
{
    FIFO,
    LIFO
}