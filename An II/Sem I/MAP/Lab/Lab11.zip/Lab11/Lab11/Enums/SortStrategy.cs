﻿namespace Lab11.Enums;

public enum SortStrategy
{
    BUBBLESORT,
    QUICKSORT
}