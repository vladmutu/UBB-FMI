﻿using Lab11;
using Lab11.Enums;
using Lab11.Tests;

Main main = new Main();
main.main(args);
